music  = {"songs": "https://www.youtube.com/watch?v=cWMxCE2HTag&list=PLNCA1T91UH31M7mN8iKSxMwwWB_mkzwT6",
          "song" :  "https://youtu.be/n_FCrCQ6-bA?feature=shared",
          "music": "https://youtu.be/ElZfdU54Cp8?feature=shared",
          "big" : "https://youtu.be/hOHKltAiKXQ?feature=shared",
          "baby" : "https://youtu.be/kffacxfA7G4?feature=shared"}
