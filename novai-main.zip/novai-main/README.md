# enter your Openai api key in "opnai_api_key" text.
# Enter your newsapi key in "News_api_key"
# Download all the required module by executing "pip install -r requirements.txt" in your visual studio terminal.
# You can add more musics in the musicLib.py
